#!/usr/bin/env bash

sudo wget -P /tmp https://bintray.com/artifact/download/vertx/downloads/vert.x-3.4.2-full.tar.gz
sudo tar -xzf /tmp/vert.x-3.4.2-full.tar.gz -C /opt/

sudo cat > /tmp/vertx.sh <<-EOF
export PATH=$PATH:/opt/vertx/bin
EOF

sudo sh /tmp/vertx.sh

sudo vertx -version